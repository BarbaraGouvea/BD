insert into autor values (1,'Paulo');
insert into autor values (2,'Renato');
insert into autor values (3,'Caio');
insert into autor values (4,'Gabriel');
insert into autor values (5,'Babi');
insert into autor values (6,'Celso');

insert into musica values (1,'rock',5);
insert into musica values (2,'pagode',5);
insert into musica values (3,'axe',5);
insert into musica values (4,'classico',5);
insert into musica values (5,'internacional',5);
insert into musica values (6,'MPB',5);
insert into musica values (7,'Sertanejol',5);

insert into CD_CATEGORIA values (1,5,10);
insert into CD_CATEGORIA values (2,5,20);
insert into CD_CATEGORIA values (3,15,20);
insert into CD_CATEGORIA values (4,15,25);
insert into CD_CATEGORIA values (5,15,30);


insert into gravadora values (1,'sony','a','222','joao','www.a.com.br');
insert into gravadora values (2,'eletronic','b','223','jose','www.b.com.br');
insert into gravadora values (3,'teste','b','223','jose','www.b.com.br');
insert into gravadora values (4,'teste1','b1','555','ana','www.b1.com.br');
insert into gravadora values (5,'teste2','b2','666','maria','www.b2.com.br');

insert into cd values (1,'xuxa',10,sysdate,1,null);
insert into cd values (2,'xuxa_so_para_baixinhos',12,sysdate,2,1);
insert into cd values (3,'Bal�o M�gico',20.00,sysdate,1,null);
insert into cd values (4,'Furacao2000',5.00,sysdate,3,1);
insert into cd values (5,'Rouge',40.00,sysdate,4,null);


insert into faixa values (1,1,200);
insert into faixa values (2,2,201);
insert into faixa values (3,3,333);
insert into faixa values (4,4,444);

insert into autor_musica values (1,1);
insert into autor_musica values (2,5);
insert into autor_musica values (3,6);