/*1 - A*/
alter table Projeto 
add proj_status number(1) NOT NULL Constraint CK_proj_status CHECK (proj_status in (0,1));

/*1 - B*/
alter table Projeto modify proj_titulo varchar (252);

/*1 - C*/
alter table Projeto rename column proj_data_cadastro to  proj_data_cad

/*2 - A*/
alter table Funcionario drop column func_endereco;

desc FUNCIONARIO;

create table Endereco 
(
  end_codigo number (4) primary key,
  end_logradouro_tipo varchar(10),
  end_logradouro_nome varchar(200),
  end_logradouro_num number(5),
  end_cep number (8),
  end_bairro varchar  (100),
  end_cidade varchar (100),
  end_UF char(2)
);

create table Fun_Possui_End
(
  fun_cod number(4) references Funcionario (func_cod),
	end_cod number(4) references Endereco (end_codigo),
	Constraint func_end primary key(fun_cod,end_cod)
);

/*2 - B*/
alter table Funcionario drop constraint CK_func_salario cascade

/*2 - C*/
alter table Funcionario disable constraint UK_func_cpf cascade;
alter table Funcionario enable constraint UK_func_cpf ;

/*2 - D*/
alter table Funcionario disable constraint fun_cod;

/*3 - A*/
alter table Dependente drop column dep_parentesco;

desc Dependente;

create table Parentesco 
(
  par_codigo number (4) primary key,
  par_descricao varchar(10),
  Constraint CK_par_descricao Check (par_descricao in ('PAI', 'MAE', 'IRMAOS', 'FILHO'))
);

alter table Dependente 
add par_codigo number(4) Constraint FK_par_codigo references Parentesco(par_codigo)

/*3 - B*/
alter table Dependente add dep_CPF varchar (15);
alter table Dependente add Constraint UK_dep_CPF unique(dep_CPF) 

/*3 - C*/
alter table Dependente 
add Constraint FK_fun_cod 
foreign key(fun_cod) 
references Funcionario(func_cod) 
on delete cascade

/*4 - A*/
alter table Participa rename to Func_Projeto