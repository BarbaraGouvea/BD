create table Funcionario
(
	func_cod number(4) primary key,
	func_nome varchar2(100) not null,
	func_cpf varchar (15) Constraint UK_func_cpf unique,
	func_salario decimal (4,2) Constraint CK_func_salario Check(func_salario > 1000 ),
	func_endereco varchar(252),
	func_sexo char(1) Constraint CK_func_sexo Check(func_sexo in ('F', 'M')),
	depa_cod number (4) references Departamento(depa_cod),
	super_cod number(4) references Funcionario (func_cod)
);
 
create table Departamento
(
	depa_cod number(4) primary key,
	depa_nome varchar(30) not null,
	depa_data_inicial date
);

create table Projeto
(
	proj_cod number(4) primary key,	
	depa_cod number(4) references Departamento (depa_cod),
	proj_titulo varchar(150) not null,
	proj_descricao varchar(252),
	proj_data_cadastro date default sysdate 
);

create table Dependente
(
	fun_cod number(4) references Funcionario (func_cod),
	dep_seq number(4),
	Constraint func_dep primary key(fun_cod,dep_seq),
	dep_nome varchar (100) not null,
	dep_parentesco varchar (30) not null,
	dep_data_nasc date,
	Constraint CK_dep_parentesco Check (dep_parentesco in ('PAI', 'MAE', 'IRMAOS', 'FILHO'))
);

create table Localizacao
(
	loc_local varchar(252),
	depa_cod number(4) references Departamento(depa_cod),
	Constraint dep_loc primary key (loc_local,depa_cod)	
); 

create table Participa
(
	fun_cod number(4) references Funcionario (func_cod),
	proj_cod number(4) references Projeto (proj_cod),
	Constraint func_proj primary key(fun_cod,proj_cod),
	part_horas varchar(50)
); 
 


update cd set cd_preco_venda =
case
when cd_preco_venda <10 then cd_preco_venda *1.10
when cd_preco_venda >=10 and cd_preco_venda <13 then cd_preco_venda * 1.20

else cd_preco_venda *1.30
end;

commit;



